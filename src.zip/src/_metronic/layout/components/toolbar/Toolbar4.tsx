import React, {FC} from 'react'

const Toolbar4: FC = () => {
  return <>Toolbar 4</>
}

export {Toolbar4}
